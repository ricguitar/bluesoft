package com.vote.no.filme.tests;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

import com.vote.no.filme.logic.SaveUser;
import com.vote.no.filme.service.UserService;

public class SaveUserTest {

	private SaveUser saveuser;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private UserService userServ;
	
	@Before
	public void init (){
		saveuser = mock(SaveUser.class);
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
		userServ = mock(UserService.class);
	}
	
	@Test
	public void ShouldSaveTheCorrectNewUser() throws ServletException, IOException{
		String name = "Test", email = "test@test.com";
		request.setAttribute("name", name);
		request.setAttribute("email", email);
		saveuser.service(request, response);
		//mock(userServ, times(1)).recordUser(null);
		assertEquals(name, userServ.getUser(email).getName());
	}
	
	
}
