package com.vote.no.filme.tests;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.Before;
import org.junit.Test;
import com.vote.no.filme.domain.Usuario;
import com.vote.no.filme.service.UserService;

public class UserServiceTest {

	private UserService userServ;
	private Usuario usuario;
	
	
	@Before
	public void init(){
		userServ = mock(UserService.class);
		usuario = mock(Usuario.class);
	}
	
	@Test
	public void ShouldRecordANewUser() {
		userServ.recordUser(usuario);
		when(userServ.getUser(usuario.getEmail())).thenReturn(usuario);
		assertEquals(usuario, userServ.getUser(usuario.getEmail()));
	}
}
