package com.vote.no.filme.tests;

import static org.mockito.Mockito.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

import com.vote.no.filme.logic.Counter;

public class CounterTest {

	private Counter counter;
	private HttpServletRequest request;
	private HttpServletResponse response;

	@Before
	public void init(){
		counter = mock(Counter.class);
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	@Test
	public void ShouldCountVoteForTheFirstFilm() throws ServletException, IOException {
		counter.service(request, response);
	}

}
